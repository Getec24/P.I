-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 25/06/2024 às 02:46
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `pi_estagio`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `aluno`
--

CREATE TABLE `aluno` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `ra` char(13) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `curso` varchar(100) DEFAULT NULL,
  `unidade` varchar(100) DEFAULT NULL,
  `user_type` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `aluno`
--

INSERT INTO `aluno` (`id`, `nome`, `ra`, `senha`, `curso`, `unidade`, `user_type`) VALUES
(1, 'Vinicius Santos Tiberio', '2781392323039', '1234', 'Desenvolvimento multi plataforma', 'Fatec de Itapira', 'aluno');

-- --------------------------------------------------------

--
-- Estrutura para tabela `chat`
--

CREATE TABLE `chat` (
  `id` int(11) NOT NULL,
  `aluno_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `sender` enum('Aluno','Professor') NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `chat`
--

INSERT INTO `chat` (`id`, `aluno_id`, `message`, `sender`, `timestamp`) VALUES
(1, 1, 'sdadswa', 'Aluno', '2024-06-11 23:52:26'),
(2, 1, 'sdadswa', 'Aluno', '2024-06-11 23:54:05'),
(3, 1, 'sdadswa', 'Aluno', '2024-06-11 23:56:45'),
(4, 1, 'Tudo errado', 'Professor', '2024-06-12 17:15:33'),
(6, 1, '', 'Professor', '2024-06-12 17:28:52'),
(7, 1, 'abraço ', 'Aluno', '2024-06-18 18:41:53'),
(8, 1, 'ojhjhjhjhjerwerer\n\n', 'Professor', '2024-06-20 00:49:08');

-- --------------------------------------------------------

--
-- Estrutura para tabela `curso`
--

CREATE TABLE `curso` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `sigla` varchar(10) NOT NULL,
  `id_fatec` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `curso`
--

INSERT INTO `curso` (`id`, `nome`, `sigla`, `id_fatec`) VALUES
(1, 'Desenvolvimento de Software Multiplataforma', 'DSM', 1),
(2, 'Gestão Empresarial', 'GE', 2),
(3, 'Análise e Desenvolvimento de Sistemas', 'ADS', 3);

-- --------------------------------------------------------

--
-- Estrutura para tabela `estagios`
--

CREATE TABLE `estagios` (
  `id` int(11) NOT NULL,
  `tipo_arquivo` varchar(255) DEFAULT NULL,
  `concedente` varchar(255) NOT NULL,
  `cnpj` varchar(18) NOT NULL,
  `ruaconcedente` varchar(255) NOT NULL,
  `nomerepresentante` varchar(255) NOT NULL,
  `cargorepresentante` varchar(255) NOT NULL,
  `cpf` varchar(14) NOT NULL,
  `nomeestagiario` varchar(255) NOT NULL,
  `rgestudante` varchar(255) NOT NULL,
  `ruaestagiario` varchar(255) NOT NULL,
  `cidadeestagio` varchar(255) NOT NULL,
  `hinicio` varchar(10) NOT NULL,
  `hfinal` varchar(10) NOT NULL,
  `refinicio` varchar(10) NOT NULL,
  `refifinal` varchar(10) NOT NULL,
  `horassem` varchar(10) NOT NULL,
  `iniciovigencia` varchar(10) NOT NULL,
  `finalvigencia` varchar(10) NOT NULL,
  `bolsa` varchar(255) DEFAULT NULL,
  `bolsaextenco` varchar(255) DEFAULT NULL,
  `nseguro` varchar(255) NOT NULL,
  `nomeseguradora` varchar(255) NOT NULL,
  `matricula` varchar(255) NOT NULL,
  `curso` varchar(255) NOT NULL,
  `semestre` varchar(10) NOT NULL,
  `enderecodomiciliar` varchar(255) NOT NULL,
  `cep` varchar(9) NOT NULL,
  `cidade` varchar(255) NOT NULL,
  `estado` varchar(2) NOT NULL,
  `departestagio` varchar(255) NOT NULL,
  `bairroconc` varchar(255) NOT NULL,
  `tellconc` varchar(15) NOT NULL,
  `cepconc` varchar(9) NOT NULL,
  `cidadeconc` varchar(255) NOT NULL,
  `estadoconc` varchar(2) NOT NULL,
  `emailconc` varchar(255) NOT NULL,
  `siteconc` varchar(255) NOT NULL,
  `periodoinic` varchar(10) NOT NULL,
  `periodofinal` varchar(10) NOT NULL,
  `periodoReali` varchar(10) NOT NULL,
  `periodoRealt` varchar(10) NOT NULL,
  `hiniciosabado` varchar(10) NOT NULL,
  `hfinalsabado` varchar(10) NOT NULL,
  `atividane1` varchar(255) NOT NULL,
  `descricaoativ1` varchar(255) NOT NULL,
  `objresult1` varchar(255) NOT NULL,
  `periodo1` varchar(10) NOT NULL,
  `atividane2` varchar(255) NOT NULL,
  `descricaoativ2` varchar(255) NOT NULL,
  `objresult2` varchar(255) NOT NULL,
  `periodo2` varchar(10) NOT NULL,
  `atividane3` varchar(255) NOT NULL,
  `descricaoativ3` varchar(255) NOT NULL,
  `objresult3` varchar(255) NOT NULL,
  `periodo3` varchar(10) NOT NULL,
  `atividane4` varchar(255) NOT NULL,
  `descricaoativ4` varchar(255) NOT NULL,
  `objresult4` varchar(255) NOT NULL,
  `periodo4` varchar(10) NOT NULL,
  `atividane5` varchar(255) NOT NULL,
  `descricaoativ5` varchar(255) NOT NULL,
  `objresult5` varchar(255) NOT NULL,
  `periodo5` varchar(10) NOT NULL,
  `emailestagiario` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `estagios`
--

INSERT INTO `estagios` (`id`, `tipo_arquivo`, `concedente`, `cnpj`, `ruaconcedente`, `nomerepresentante`, `cargorepresentante`, `cpf`, `nomeestagiario`, `rgestudante`, `ruaestagiario`, `cidadeestagio`, `hinicio`, `hfinal`, `refinicio`, `refifinal`, `horassem`, `iniciovigencia`, `finalvigencia`, `bolsa`, `bolsaextenco`, `nseguro`, `nomeseguradora`, `matricula`, `curso`, `semestre`, `enderecodomiciliar`, `cep`, `cidade`, `estado`, `departestagio`, `bairroconc`, `tellconc`, `cepconc`, `cidadeconc`, `estadoconc`, `emailconc`, `siteconc`, `periodoinic`, `periodofinal`, `periodoReali`, `periodoRealt`, `hiniciosabado`, `hfinalsabado`, `atividane1`, `descricaoativ1`, `objresult1`, `periodo1`, `atividane2`, `descricaoativ2`, `objresult2`, `periodo2`, `atividane3`, `descricaoativ3`, `objresult3`, `periodo3`, `atividane4`, `descricaoativ4`, `objresult4`, `periodo4`, `atividane5`, `descricaoativ5`, `objresult5`, `periodo5`, `emailestagiario`) VALUES
(1, 'hidden', '123', '123', '321', '321', '321', 'oFHIVIKXYHPbf9', '321', 'oFHIVIKXYHPbf9yOCvidIA==', '321', '321', '321', '321', '321', '321', '321', '2024-06-14', '2024-06-17', '32', '1321', '321', '321', '321', '321', '321', '321', '321', '321', '32', '321', '321', '321', '321', '321', '32', 'a@a', 'https://www.a.com', '2024-06-15', '2024-06-12', '2024-06-06', '2024-06-14', '2024-06-17', '2024-06-24', '321', '321', '321', '321', '321', '321', '321', '321', '321', '321', '321', '321', '321', '321', '321', '321', '321', '321', '321', '321', 'a@a'),
(2, 'NaoObrigatori', '123', '321', '321', '321', '321', 'oFHIVIKXYHPbf9', '321', 'oFHIVIKXYHPbf9yOCvidIA==', '321', '321', '321', '321', '321', '32', '1321', '2024-06-01', '2024-06-01', '0', '0', '321', '321', '321', '321', '321', '321', '321', '321', '32', '321', '321', '321', '321', '321', '32', 'a@a', 'https://www.a.com', '2002-11-08', '2002-11-08', '2002-11-08', '20002-11-0', '321', '321', '321', '321', '321', '321', '321', '321', '321', '321', '321', '321', '321', '321', '321', '321', '321', '123', '32', '1321', '321', '123', 'a@a'),
(3, 'hidden', '123', '12323', '123123213', '21312323123', '21313213', 'JcCYCYUhRG7Zyv', '1312321313', 'bZpGBotrWlXNvBAPOlMifQ==', '3132131323213213', '23213231', '32312321', '12312323', '123123232', '32132131', '12321323', '232222-02-', '222222-02-', '23213213213', '123123123', '1313231', '1321323', '123213213', '3132123', '231231322', '12312312323123', '231123123', '32131232', '31', '13123123123', '213213123', '2121312321', '123123213', '1231232', '12', '123@13423.com', 'https://213312212323.com', '275760-03-', '13233-03-3', '233132-02-', '123213-12-', '1231323232', '1232132132', '12321331232312323', '12312312312323213213213123', '12323213231321', '3213213213', '1232132132', '21313', '123213', '12312321', '12321321', '3232321312', '213123', '13331233', '3132', '33213', '3213', '43', '43', '543', '35', '435', '13213@23123.com'),
(4, 'hidden', '123', '124', '123', '132', '123', '4BPng1vxPUDKgn', '123', '4BPng1vxPUDKgnR5SwsWAg==', '13', '234', '43', '543', '543', '43', '543', '0003-04-05', '0003-04-05', '43', '543', '543', '543', '453', '453', '543', '543', '4', '43', '54', '453', '5', '43', '5', '343', '5', '4345@gmail.com', 'https://sfsffe', '0003-05-03', '0005-04-03', '0035-05-31', '0043-05-03', '453', '543', '432', '45', '43', '453', '4534', '5545645465454', '454', '6', '45', '654', '6', '45', '46', '54', '4', '4', '4', '4', '44', '4', '543@gmail.com');

-- --------------------------------------------------------

--
-- Estrutura para tabela `fatec`
--

CREATE TABLE `fatec` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `endereco` varchar(255) NOT NULL,
  `cod` char(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `fatec`
--

INSERT INTO `fatec` (`id`, `nome`, `endereco`, `cod`) VALUES
(1, 'Fatec de Itapira', 'Rua Exemplo, 123, Itapira - SP', '001'),
(2, 'Fatec de Campinas', 'Av. Outro Exemplo, 456, Campinas - SP', '002'),
(3, 'Fatec de São Paulo', 'Rua Outro Lugar, 789, São Paulo - SP', '003');

-- --------------------------------------------------------

--
-- Estrutura para tabela `professor`
--

CREATE TABLE `professor` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `rm` char(10) NOT NULL,
  `id_curso` int(11) DEFAULT NULL,
  `id_fatec` int(11) DEFAULT NULL,
  `senha` varchar(255) NOT NULL,
  `user_type` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `professor`
--

INSERT INTO `professor` (`id`, `nome`, `rm`, `id_curso`, `id_fatec`, `senha`, `user_type`) VALUES
(1, 'Professor A', '123456', 1, 1, '123', 'professor'),
(2, 'Professor B', 'RM654321', 2, 2, '', '3'),
(3, 'Professor C', 'RM111222', 3, 3, '', '3');

-- --------------------------------------------------------

--
-- Estrutura para tabela `relatorio`
--

CREATE TABLE `relatorio` (
  `id` int(11) NOT NULL,
  `tipo_arquivo` varchar(35) DEFAULT NULL,
  `matricula` varchar(18) DEFAULT NULL,
  `nome` varchar(35) DEFAULT NULL,
  `curso` varchar(20) NOT NULL,
  `semestre` varchar(20) NOT NULL,
  `ra` int(13) NOT NULL,
  `nomedaempresa` varchar(35) NOT NULL,
  `supervisor` varchar(35) NOT NULL,
  `cdsde` varchar(35) NOT NULL,
  `data` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `relatorio`
--

INSERT INTO `relatorio` (`id`, `tipo_arquivo`, `matricula`, `nome`, `curso`, `semestre`, `ra`, `nomedaempresa`, `supervisor`, `cdsde`, `data`) VALUES
(1, 'Relatorio Parcial', '123', '123', '123', '', 123, '123', '123', '123', NULL),
(2, 'Relatorio Parcial', '123', '132', '123', '', 123, '123', '123', '123', NULL),
(3, 'Relatorio Parcial', '123', '132', '123', '', 123, '123', '123', '123', NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `relatorio2`
--

CREATE TABLE `relatorio2` (
  `id` int(11) NOT NULL,
  `tipo_arquivo` int(11) DEFAULT NULL,
  `nome` varchar(35) DEFAULT NULL,
  `ra` int(13) DEFAULT NULL,
  `nomedaempresa` varchar(35) DEFAULT NULL,
  `svrnome` varchar(35) DEFAULT NULL,
  `cargo` varchar(35) DEFAULT NULL,
  `inicio` date DEFAULT NULL,
  `termino` date DEFAULT NULL,
  `dia` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `relatorio2`
--

INSERT INTO `relatorio2` (`id`, `tipo_arquivo`, `nome`, `ra`, `nomedaempresa`, `svrnome`, `cargo`, `inicio`, `termino`, `dia`) VALUES
(1, 0, '123', 123, '123', '123', '123', '2024-06-01', '2024-06-22', '2024-06-19');

-- --------------------------------------------------------

--
-- Estrutura para tabela `uploads`
--

CREATE TABLE `uploads` (
  `id` int(11) NOT NULL,
  `aluno_id` int(11) DEFAULT NULL,
  `id_professor` int(11) DEFAULT NULL,
  `id_curso` int(11) DEFAULT NULL,
  `file_path` varchar(255) NOT NULL,
  `upload_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `file_type` varchar(255) NOT NULL,
  `status` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `uploads`
--

INSERT INTO `uploads` (`id`, `aluno_id`, `id_professor`, `id_curso`, `file_path`, `upload_date`, `file_type`, `status`) VALUES
(1, 1, 1, 1, '../uploads/DSM/Diagrama de Precedencia.pdf', '2024-06-11 23:48:54', '', 1),
(2, 1, 2, 2, '../uploads/GE/Diagrama de Precedencia.pdf', '2024-06-12 00:17:33', '', 0),
(3, 1, 1, 1, '../uploads/DSM/Diagrama de Precedencia.pdf', '2024-06-11 23:37:48', 'TermoPlano', 1),
(4, 1, 1, 1, '../uploads/DSM/e.pdf', '2024-06-18 18:36:52', 'TermoPlano', 1),
(5, 1, 1, 1, '../uploads/DSM/1.pdf', '2024-06-20 00:44:56', 'TermoPlano', 1);

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `aluno`
--
ALTER TABLE `aluno`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`id`),
  ADD KEY `aluno_id` (`aluno_id`);

--
-- Índices de tabela `curso`
--
ALTER TABLE `curso`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_fatec` (`id_fatec`);

--
-- Índices de tabela `estagios`
--
ALTER TABLE `estagios`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `fatec`
--
ALTER TABLE `fatec`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `professor`
--
ALTER TABLE `professor`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_curso` (`id_curso`),
  ADD KEY `id_fatec` (`id_fatec`);

--
-- Índices de tabela `relatorio`
--
ALTER TABLE `relatorio`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `relatorio2`
--
ALTER TABLE `relatorio2`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `uploads`
--
ALTER TABLE `uploads`
  ADD PRIMARY KEY (`id`),
  ADD KEY `aluno_id` (`aluno_id`),
  ADD KEY `id_professor` (`id_professor`),
  ADD KEY `id_curso` (`id_curso`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `aluno`
--
ALTER TABLE `aluno`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `chat`
--
ALTER TABLE `chat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `curso`
--
ALTER TABLE `curso`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `estagios`
--
ALTER TABLE `estagios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `fatec`
--
ALTER TABLE `fatec`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `professor`
--
ALTER TABLE `professor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `relatorio`
--
ALTER TABLE `relatorio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `relatorio2`
--
ALTER TABLE `relatorio2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `uploads`
--
ALTER TABLE `uploads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `chat`
--
ALTER TABLE `chat`
  ADD CONSTRAINT `chat_ibfk_1` FOREIGN KEY (`aluno_id`) REFERENCES `aluno` (`id`);

--
-- Restrições para tabelas `curso`
--
ALTER TABLE `curso`
  ADD CONSTRAINT `curso_ibfk_1` FOREIGN KEY (`id_fatec`) REFERENCES `fatec` (`id`);

--
-- Restrições para tabelas `professor`
--
ALTER TABLE `professor`
  ADD CONSTRAINT `professor_ibfk_1` FOREIGN KEY (`id_curso`) REFERENCES `curso` (`id`),
  ADD CONSTRAINT `professor_ibfk_2` FOREIGN KEY (`id_fatec`) REFERENCES `fatec` (`id`);

--
-- Restrições para tabelas `uploads`
--
ALTER TABLE `uploads`
  ADD CONSTRAINT `uploads_ibfk_1` FOREIGN KEY (`aluno_id`) REFERENCES `aluno` (`id`),
  ADD CONSTRAINT `uploads_ibfk_2` FOREIGN KEY (`id_professor`) REFERENCES `professor` (`id`),
  ADD CONSTRAINT `uploads_ibfk_3` FOREIGN KEY (`id_curso`) REFERENCES `curso` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
