<?php
// documentacao.php
include 'header.php';
require 'config.php';

$stmt = $pdo->query('SELECT id, nome FROM Professor');
$professores = $stmt->fetchAll(PDO::FETCH_ASSOC);

$alert = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['file'])) {
    $aluno_id = $_SESSION['id'];
    $professor_id = $_POST['professor'];
    $file_type = $_POST['file_type'];
    $file = $_FILES['file'];

    $stmt = $pdo->prepare('SELECT c.sigla FROM Curso c JOIN Professor p ON c.id = p.id_curso WHERE p.id = ?');
    $stmt->execute([$professor_id]);
    $curso = $stmt->fetch();

    if ($curso) {
        $curso_sigla = $curso['sigla'];
        $target_dir = "../uploads/$curso_sigla/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        $target_file = $target_dir . basename($file["name"]);
        $file_extension = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        $max_file_size = 2 * 1024 * 1024; 

        
        if ($file_extension != "pdf") {
            $alert = "Erro: Apenas arquivos PDF são permitidos.";
        } elseif ($file["size"] > $max_file_size) {
            $alert = "Erro: O arquivo excede o tamanho máximo permitido de 2MB.";
        } elseif (move_uploaded_file($file["tmp_name"], $target_file)) {
        
            $stmt = $pdo->prepare('SELECT id_curso FROM Professor WHERE id = ?');
            $stmt->execute([$professor_id]);
            $id_curso = $stmt->fetchColumn();

           
            $stmt = $pdo->prepare('INSERT INTO Uploads (aluno_id, id_professor, id_curso, file_path, file_type) VALUES (?, ?, ?, ?, ?)');
            $stmt->execute([$aluno_id, $professor_id, $id_curso, $target_file, $file_type]);

            $alert = "O arquivo " . htmlspecialchars(basename($file["name"])) . " foi enviado com sucesso.";
        } else {
            $alert = "Desculpe, houve um erro ao enviar seu arquivo.";
        }
    } else {
        $alert = "Erro: Curso não encontrado.";
    }
}
?>

<main>
    <div class="content">
        <?php if ($alert): ?>
            <div class="alert">
                <?php echo htmlspecialchars($alert); ?>
            </div>
        <?php endif; ?>
        <div class="upload-section">
            <h2>Upload de Arquivos</h2>
            <form action="documentacao.php" method="post" enctype="multipart/form-data">
                <label for="professor">Selecione o Professor:</label>
                <select id="professor" name="professor" required>
                    <?php foreach ($professores as $professor): ?>
                        <option value="<?php echo $professor['id']; ?>"><?php echo htmlspecialchars($professor['nome']); ?></option>
                    <?php endforeach; ?>
                </select>
                
                <label for="file_type">Tipo de Arquivo:</label>
                <select id="file_type" name="file_type" required>
                    <option value="TermoPlano">Termo de Compromisso e Plano de Atividades</option>
                    <option value="RelatorioFinal">Relatório Final</option>
                    <option value="RelatorioParcial">Relatório Parcial</option>
                </select>

                <label for="file">Selecione o arquivo:</label>
                <input type="file" id="file" name="file" required>
                
                <button type="submit">Upload</button>
            </form>
        </div>
        <div class="download-section">
            <h2>Solicitação Documentação</h2>
            <form action="processa_estagio.php" method="post">
                <label for="estagio">Estágio é obrigatório?</label>
                <select id="estagio" name="estagio" required>
                    <option value="Sim">Sim</option>
                </select>

                <label for="remunerado">Estágio é remunerado?</label>
                <select id="remunerado" name="remunerado" required>
                    <option value="Sim">Sim</option>
                    <option value="Nao">Não</option>
                </select>

                <button type="submit">Enviar</button>
            </form>
            
            <form action="processa_relatorio.php" method="post">
                <label for="tipo_relatorio">Tipo de Relatório:</label>
                <select id="tipo_relatorio" name="tipo_relatorio" required>
                    <option value="Parcial">Parcial</option>
                    <option value="Final">Final</option>
                </select>

                <button type="submit">Enviar</button>
            </form>
        </div>
    </div>
</main>
</html>
