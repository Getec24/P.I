<?php
// header.php
session_start();
$nome = isset($_SESSION['nome']) ? $_SESSION['nome'] : 'Visitante';
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portal de Estágio</title>
    <link rel="stylesheet" href="../css/home.css">
    <link rel="stylesheet" href="../css/documentacao.css">
</head>
<body>
    <header>
        <div class="header-content">
            <div class="welcome">
                Bem vindo: <?php echo htmlspecialchars($nome); ?>
            </div>
            <nav>
                <ul>
                    <li><a href="home.php">Home</a></li>
                    <li><a href="documentacao.php">Solicitação</a></li>
                    <li><a href="status.php">Status</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>
</body>
</html>
