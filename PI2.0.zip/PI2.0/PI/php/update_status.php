<?php
require 'config.php';

$upload_id = $_POST['upload_id'];
$status = $_POST['status'];

$stmt = $pdo->prepare('UPDATE Uploads SET status = ? WHERE id = ?');
$stmt->execute([$status, $upload_id]);
?>
