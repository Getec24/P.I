<?php
// status.php
include 'header.php';
require 'config.php';

// Obter o ID do aluno da sessão
$aluno_id = $_SESSION['id'];

// Obter os uploads do aluno
$stmt = $pdo->prepare('SELECT id, file_type, file_path, DATE_FORMAT(upload_date, "%d/%m/%Y %H:%i") as upload_date, status FROM Uploads WHERE aluno_id = ?');
$stmt->execute([$aluno_id]);
$uploads = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Obter mensagens de chat do professor
$stmt = $pdo->prepare('SELECT message, sender, DATE_FORMAT(timestamp, "%d/%m/%Y %H:%i") as timestamp FROM Chat WHERE aluno_id = ? ORDER BY timestamp ASC');
$stmt->execute([$aluno_id]);
$chats = $stmt->fetchAll(PDO::FETCH_ASSOC);

$alert = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['file'])) {
    $upload_id = $_POST['upload_id'];
    $file = $_FILES['file'];
    
    // Obter a sigla do curso do upload
    $stmt = $pdo->prepare('SELECT c.sigla FROM Curso c JOIN Uploads u ON c.id = u.id_curso WHERE u.id = ?');
    $stmt->execute([$upload_id]);
    $curso = $stmt->fetch();

    if ($curso) {
        $curso_sigla = $curso['sigla'];
        $target_dir = "../uploads/$curso_sigla/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        $target_file = $target_dir . basename($file["name"]);
        $file_extension = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        $max_file_size = 2 * 1024 * 1024; // Limite de 2MB

        // Verificar se o arquivo é um PDF
        if ($file_extension != "pdf") {
            $alert = "Erro: Apenas arquivos PDF são permitidos.";
        } elseif ($file["size"] > $max_file_size) {
            $alert = "Erro: O arquivo excede o tamanho máximo permitido de 2MB.";
        } elseif (move_uploaded_file($file["tmp_name"], $target_file)) {
            // Atualizar o caminho do arquivo na tabela Uploads
            $stmt = $pdo->prepare('UPDATE Uploads SET file_path = ?, upload_date = NOW() WHERE id = ?');
            $stmt->execute([$target_file, $upload_id]);

            $alert = "O arquivo " . htmlspecialchars(basename($file["name"])) . " foi enviado com sucesso.";
        } else {
            $alert = "Desculpe, houve um erro ao enviar seu arquivo.";
        }
    } else {
        $alert = "Erro: Curso não encontrado.";
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['chat_message'])) {
    $message = $_POST['chat_message'];
    $stmt = $pdo->prepare('INSERT INTO Chat (aluno_id, message, sender) VALUES (?, ?, "Aluno")');
    $stmt->execute([$aluno_id, $message]);
}
?>

<link rel="stylesheet" href="../css/status.css">
<main>
    <div class="content">
        <?php if ($alert): ?>
            <div class="alert">
                <?php echo htmlspecialchars($alert); ?>
            </div>
        <?php endif; ?>
        <div class="uploads-section">
            <h2>Meus Uploads</h2>
            <table>
                <thead>
                    <tr>
                        <th>Tipo do Arquivo</th>
                        <th>Nome do Arquivo</th>
                        <th>Data</th>
                        <th>Status</th>
                        <th>Substituir</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($uploads as $upload): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($upload['file_type']); ?></td>
                            <td><a href="<?php echo htmlspecialchars($upload['file_path']); ?>" download><?php echo htmlspecialchars(basename($upload['file_path'])); ?></a></td>
                            <td><?php echo htmlspecialchars($upload['upload_date']); ?></td>
                            <td>
                                <input type="checkbox" <?php echo $upload['status'] == 1 ? 'checked' : ''; ?> disabled> Aprovado
                                <input type="checkbox" <?php echo $upload['status'] == 0 ? 'checked' : ''; ?> disabled> Reprovado
                            </td>
                            <td>
                                <?php if ($upload['status'] == 0): ?>
                                    <form action="status.php" method="post" enctype="multipart/form-data">
                                        <input type="file" name="file" required>
                                        <input type="hidden" name="upload_id" value="<?php echo $upload['id']; ?>">
                                        <button type="submit">Substituir</button>
                                    </form>
                                <?php else: ?>
                                    <button disabled>Substituir</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="chat-section">
            <h2>Chat com o Professor</h2>
            <div class="chat-box">
                <?php foreach ($chats as $chat): ?>
                    <div class="chat-message <?php echo $chat['sender'] == 'Professor' ? 'professor' : 'aluno'; ?>">
                        <p><?php echo htmlspecialchars($chat['message']); ?></p>
                        <br>
                        <span class="timestamp"><?php echo htmlspecialchars($chat['timestamp']); ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
            <form action="status.php" method="post">
                <textarea name="chat_message" required></textarea>
                <button type="submit">Enviar</button>
            </form>
        </div>
    </div>
</main>
</html>
