<?php
// processa_estagio.php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $remunerado = $_POST['remunerado'];
    
    if ($remunerado == 'Sim') {
        header('Location: EstagioObrR.php');
    } else {
        header('Location: EstagioObrNR.php');
    }
    exit();
}
?>
