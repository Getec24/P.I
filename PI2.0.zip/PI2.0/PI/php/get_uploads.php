<?php
require 'config.php';

$aluno_id = $_GET['aluno_id'];

try {
    // Obter uploads do aluno
    $stmt = $pdo->prepare('SELECT id, file_type, file_path, status FROM Uploads WHERE aluno_id = ?');
    $stmt->execute([$aluno_id]);
    $uploads = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Obter mensagens de chat
    $stmt = $pdo->prepare('SELECT message, sender, DATE_FORMAT(timestamp, "%d/%m/%Y %H:%i") as timestamp FROM Chat WHERE aluno_id = ? ORDER BY timestamp ASC');
    $stmt->execute([$aluno_id]);
    $chats = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['uploads' => $uploads, 'chats' => $chats]);
} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>
