<?php
// EstagioObrR.php
include 'header.php';
?>
<link rel="stylesheet" href="../css/estagio.css">
<script src="../js/pizzip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.7.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/docxtemplater/3.22.3/docxtemplater.js"></script>
<main>
    <div class="content">
        <div class="form-section">
            <h2>RFinal</h2>
            <form id="rfinal">
                <!-- Form Fields -->
                <div class="input-group">
                    <label for="nome">Nome: </label>
                    <input type="text" id="nome" name="nome" required>
                </div>
                <div class="input-group">
                    <label for="ra">RA:</label>
                    <input type="text" id="ra" name="ra" required>
                </div>
                <div class="input-group">
                    <label for="nomedaempresa">Nome da Empresa:</label>
                    <input type="text" id="nomedaempresa" name="nomedaempresa" required>
                </div>
                <div class="input-group">
                    <label for="svrnome">Nome do supervisor do estagiário:</label>
                    <input type="text" id="svrnome" name="svrnome" required>
                </div>
                <div class="input-group">
                    <label for="cargo">Cargo do supervisor do estagiário: </label>
                    <input type="text" id="cargo" name="cargo" required>
                </div>
                <div class="input-group">
                    <label for="inicio">Data de início do estágio:</label>
                    <input type="date" id="inicio" name="inicio" required>
                </div>
                <div class="input-group">
                    <label for="termino">Data de término do estágio:</label>
                    <input type="date" id="termino" name="termino" required>
                </div>
                <div class="input-group">
                    <label for="dia">Data:</label>
                    <input type="date" id="dia" name="dia" required>
                </div>
                <input type="hidden" id="tipo_arquivo" name="tipo_arquivo" value="Relatorio Final">
                <button type="submit">Enviar</button>
                </form>
    <script>
        document.getElementById('rfinal').addEventListener('submit', function(event) {
            event.preventDefault();
            
            const formData = new FormData(document.getElementById('rfinal'));

            fetch('save_data3.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                alert('Dados salvos com sucesso!');
                console.log(data);
            })
            .catch(error => {
                alert('Erro ao salvar os dados.');
                console.error(error);
            });

            generateDocx();
        });

        function generateDocx() {
            fetch('../DocBase/rf.docx')
                .then(response => response.arrayBuffer())
                .then(data => {
                    const zip = new PizZip(data);
                    const doc = new window.docxtemplater(zip, { paragraphLoop: true, linebreaks: true });

                    const values = {
                        nome: document.getElementById('nome').value,
                        ra: document.getElementById('ra').value,
                        nomedaempresa: document.getElementById('nomedaempresa').value,
                        svrnome: document.getElementById('svrnome').value,
                        cargo: document.getElementById('cargo').value,
                        inicio: document.getElementById('inicio').value,
                        termino: document.getElementById('termino').value,
                        dia: document.getElementById('dia').value,  
                    };

                    doc.setData(values);

                    try {
                        doc.render();
                    } catch (error) {
                        console.error(error);
                        throw error;
                    }

                    const out = doc.getZip().generate({
                        type: 'blob',
                        mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                    });

                    saveAs(out, 'Relatorio_Final.docx');
                })
                .catch(error => console.error(error));
        }
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/2.0.5/FileSaver.min.js"></script>
</html>
