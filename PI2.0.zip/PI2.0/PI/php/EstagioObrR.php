<?php
// EstagioObrR.php
include 'header.php';
?>
<link rel="stylesheet" href="../css/estagio.css">
<script src="../js/pizzip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.7.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/docxtemplater/3.22.3/docxtemplater.js"></script>
<main>
    <div class="content">
        <div class="form-section">
            <h2>Formulário Remunerado Sim</h2>
            <form id="formEstagio">
                <!-- Form Fields -->
                <div class="input-group">
                    <label for="concedente">Nome da concedente:</label>
                    <input type="text" id="concedente" name="concedente" required>
                </div>
                <div class="input-group">
                    <label for="cnpj">CNPJ da concedente:</label>
                    <input type="text" id="cnpj" name="cnpj" required>
                </div>
                <div class="input-group">
                    <label for="ruaconcedente">Endereço da concedente:</label>
                    <input type="text" id="ruaconcedente" name="ruaconcedente" required>
                </div>
                <div class="input-group">
                    <label for="nomerepresentante">Nome do Representante da Concedente:</label>
                    <input type="text" id="nomerepresentante" name="nomerepresentante" required>
                </div>
                <div class="input-group">
                    <label for="cargorepresentante">Cargo do Representante:</label>
                    <input type="text" id="cargorepresentante" name="cargorepresentante" required>
                </div>
                <div class="input-group">
                    <label for="cpf">CPF do Representante:</label>
                    <input type="text" id="cpf" name="cpf" required>
                </div>
                <div class="input-group">
                    <label for="nomeestagiario">Nome do Estagiário:</label>
                    <input type="text" id="nomeestagiario" name="nomeestagiario" required>
                </div>
                <div class="input-group">
                    <label for="rgestudante">RG do Estagiário:</label>
                    <input type="text" id="rgestudante" name="rgestudante" required>
                </div>
                <div class="input-group">
                    <label for="ruaestagiario">Endereço do Estagiário:</label>
                    <input type="text" id="ruaestagiario" name="ruaestagiario" required>
                </div>
                <div class="input-group">
                    <label for="cidadeestagio">Cidade do Estagiário:</label>
                    <input type="text" id="cidadeestagio" name="cidadeestagio" required>
                </div>
                <div class="input-group">
                    <label for="hinicio">Horário do início do Estágio:</label>
                    <input type="text" id="hinicio" name="hinicio" required>
                </div>
                <div class="input-group">
                    <label for="hfinal">Horário do final do Estágio:</label>
                    <input type="text" id="hfinal" name="hfinal" required>
                </div>
                <div class="input-group">
                    <label for="refinicio">Horário de almoço início:</label>
                    <input type="text" id="refinicio" name="refinicio" required>
                </div>
                <div class="input-group">
                    <label for="refifinal">Horário de almoço final:</label>
                    <input type="text" id="refifinal" name="refifinal" required>
                </div>
                <div class="input-group">
                    <label for="horassem">Carga Horária Semanal:</label>
                    <input type="text" id="horassem" name="horassem" required>
                </div>
                <div class="input-group">
                    <label for="iniciovigencia">Início da Vigência:</label>
                    <input type="date" id="iniciovigencia" name="iniciovigencia" required>
                </div>
                <div class="input-group">
                    <label for="finalvigencia">Fim da Vigência:</label>
                    <input type="date" id="finalvigencia" name="finalvigencia" required>
                </div>
                <div class="input-group">
                    <label for="bolsa">Valor da Bolsa-Estágio:</label>
                    <input type="text" id="bolsa" name="bolsa" required>
                </div>
                <div class="input-group">
                    <label for="bolsaextenco">Valor da Bolsa-Estágio por extenso:</label>
                    <input type="text" id="bolsaextenco" name="bolsaextenco" required>
                </div>
                <div class="input-group">
                    <label for="nseguro">Seguro de Acidentes:</label>
                    <input type="text" id="nseguro" name="nseguro" required>
                </div>
                <div class="input-group">
                    <label for="nomeseguradora">Nome Seguradora:</label>
                    <input type="text" id="nomeseguradora" name="nomeseguradora" required>
                </div>
                <h3>Plano de Atividades</h3>
                <div class="input-group">
                    <label for="matricula">Matrícula:</label>
                    <input type="text" id="matricula" name="matricula" required>
                </div>
                <div class="input-group">
                    <label for="curso">Curso:</label>
                    <input type="text" id="curso" name="curso" required>
                </div>
                <div class="input-group">
                    <label for="semestre">Semestre:</label>
                    <input type="text" id="semestre" name="semestre" required>
                </div>
                <div class="input-group">
                    <label for="enderecodomiciliar">Endereço domiciliar:</label>
                    <input type="text" id="enderecodomiciliar" name="enderecodomiciliar" required>
                </div>
                <div class="input-group">
                    <label for="cep">CEP do estagiário:</label>
                    <input type="text" id="cep" name="cep" required>
                </div>
                <div class="input-group">
                    <label for="cidade">Cidade:</label>
                    <input type="text" id="cidade" name="cidade" required>
                </div>
                <div class="input-group">
                    <label for="estado">Estado:</label>
                    <input type="text" id="estado" name="estado" required>
                </div>
                <div class="input-group">
                    <label for="emailestagiario">Endereço eletrônico estudante (e-mail):</label>
                    <input type="email" id="emailestagiario" name="emailestagiario" required>
                </div>
                <div class="input-group">
                    <label for="departestagio">Divisão ou departamento:</label>
                    <input type="text" id="departestagio" name="departestagio" required>
                </div>
                <div class="input-group">
                    <label for="bairroconc">Bairro Empresa:</label>
                    <input type="text" id="bairroconc" name="bairroconc" required>
                </div>
                <div class="input-group">
                    <label for="tellconc">Telefone/ramal:</label>
                    <input type="text" id="tellconc" name="tellconc" required>
                </div>
                <div class="input-group">
                    <label for="cepconc">CEP empresa:</label>
                    <input type="text" id="cepconc" name="cepconc" required>
                </div>
                <div class="input-group">
                    <label for="cidadeconc">Cidade empresa:</label>
                    <input type="text" id="cidadeconc" name="cidadeconc" required>
                </div>
                <div class="input-group">
                    <label for="estadoconc">Estado empresa:</label>
                    <input type="text" id="estadoconc" name="estadoconc" required>
                </div>
                <div class="input-group">
                    <label for="emailconc">Endereço eletrônico (e-mail) concedente:</label>
                    <input type="email" id="emailconc" name="emailconc" required>
                </div>
                <div class="input-group">
                    <label for="siteconc">Site empresa:</label>
                    <input type="url" id="siteconc" name="siteconc">
                </div>
                <div class="input-group">
                    <label for="periodoinic">Período Inicial:</label>
                    <input type="date" id="periodoinic" name="periodoinic" required>
                </div>
                <div class="input-group">
                    <label for="periodofinal">Período Final:</label>
                    <input type="date" id="periodofinal" name="periodofinal" required>
                </div>
                <div class="input-group">
                    <label for="periodoReali">Período Real Inicial:</label>
                    <input type="date" id="periodoReali" name="periodoReali" required>
                </div>
                <div class="input-group">
                    <label for="periodoRealt">Período Real Final:</label>
                    <input type="date" id="periodoRealt" name="periodoRealt" required>
                </div>
                <div class="input-group">
                    <label for="hiniciosabado">Início sábado:</label>
                    <input type="text" id="hiniciosabado" name="hiniciosabado" required>
                </div>
                <div class="input-group">
                    <label for="hfinalsabado">Final sábado:</label>
                    <input type="text" id="hfinalsabado" name="hfinalsabado" required>
                </div>
                <div class="input-group">
                    <label for="atividane1">Atividade:</label>
                    <input type="text" id="atividane1" name="atividane1" required>
                </div>
                <div class="input-group">
                    <label for="descricaoativ1">Descrição de Atividade:</label>
                    <input type="text" id="descricaoativ1" name="descricaoativ1" required>
                </div>
                <div class="input-group">
                    <label for="objresult1">Objetivo:</label>
                    <input type="text" id="objresult1" name="objresult1" required>
                </div>
                <div class="input-group">
                    <label for="periodo1">Período:</label>
                    <input type="text" id="periodo1" name="periodo1" required>
                </div>
                <div class="input-group">
                    <label for="atividane2">Atividade:</label>
                    <input type="text" id="atividane2" name="atividane2" required>
                </div>
                <div class="input-group">
                    <label for="descricaoativ2">Descrição de Atividade:</label>
                    <input type="text" id="descricaoativ2" name="descricaoativ2" required>
                </div>
                <div class="input-group">
                    <label for="objresult2">Objetivo:</label>
                    <input type="text" id="objresult2" name="objresult2" required>
                </div>
                <div class="input-group">
                    <label for="periodo2">Período:</label>
                    <input type="text" id="periodo2" name="periodo2" required>
                </div>
                <div class="input-group">
                    <label for="atividane3">Atividade:</label>
                    <input type="text" id="atividane3" name="atividane3" required>
                </div>
                <div class="input-group">
                    <label for="descricaoativ3">Descrição de Atividade:</label>
                    <input type="text" id="descricaoativ3" name="descricaoativ3" required>
                </div>
                <div class="input-group">
                    <label for="objresult3">Objetivo:</label>
                    <input type="text" id="objresult3" name="objresult3" required>
                </div>
                <div class="input-group">
                    <label for="periodo3">Período:</label>
                    <input type="text" id="periodo3" name="periodo3" required>
                </div>
                <div class="input-group">
                    <label for="atividane4">Atividade:</label>
                    <input type="text" id="atividane4" name="atividane4" required>
                </div>
                <div class="input-group">
                    <label for="descricaoativ4">Descrição de Atividade:</label>
                    <input type="text" id="descricaoativ4" name="descricaoativ4" required>
                </div>
                <div class="input-group">
                    <label for="objresult4">Objetivo:</label>
                    <input type="text" id="objresult4" name="objresult4" required>
                </div>
                <div class="input-group">
                    <label for="periodo4">Período:</label>
                    <input type="text" id="periodo4" name="periodo4" required>
                </div>
                <div class="input-group">
                    <label for="atividane5">Atividade:</label>
                    <input type="text" id="atividane5" name="atividane5" required>
                </div>
                <div class="input-group">
                    <label for="descricaoativ5">Descrição de Atividade:</label>
                    <input type="text" id="descricaoativ5" name="descricaoativ5" required>
                </div>
                <div class="input-group">
                    <label for="objresult5">Objetivo:</label>
                    <input type="text" id="objresult5" name="objresult5" required>
                </div>
                <div class="input-group">
                    <label for="periodo5">Período:</label>
                    <input type="text" id="periodo5" name="periodo5" required>
                </div>
                <input type="hidden" id="tipo_arquivo" name="tipo_arquivo" value="hidden">
                <input type="hidden" id="ra" name="ra">
                <button type="submit">Enviar</button>
            </form>
        </div>
    </div>
    <script>
        document.getElementById('formEstagio').addEventListener('submit', function(event) {
            event.preventDefault();
            
            const formData = new FormData(document.getElementById('formEstagio'));

            fetch('save_data.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                alert('Dados salvos com sucesso!');
                console.log(data);
            })
            .catch(error => {
                alert('Erro ao salvar os dados.');
                console.error(error);
            });

            generateDocx();
        });

        function generateDocx() {
            fetch('../DocBase/obrigatorio.docx')
                .then(response => response.arrayBuffer())
                .then(data => {
                    const zip = new PizZip(data);
                    const doc = new window.docxtemplater(zip, { paragraphLoop: true, linebreaks: true });

                    const values = {
                        tipo_arquivo: document.getElementById('tipo_arquivo').value,
                        concedente: document.getElementById('concedente').value,
                        cnpj: document.getElementById('cnpj').value,
                        ruaconcedente: document.getElementById('ruaconcedente').value,
                        nomerepresentante: document.getElementById('nomerepresentante').value,
                        cargorepresentante: document.getElementById('cargorepresentante').value,
                        cpf: document.getElementById('cpf').value,
                        nomeestagiario: document.getElementById('nomeestagiario').value,
                        rgestudante: document.getElementById('rgestudante').value,
                        ruaestagiario: document.getElementById('ruaestagiario').value,
                        cidadeestagio: document.getElementById('cidadeestagio').value,
                        hinicio: document.getElementById('hinicio').value,
                        hfinal: document.getElementById('hfinal').value,
                        refinicio: document.getElementById('refinicio').value,
                        refifinal: document.getElementById('refifinal').value,
                        horassem: document.getElementById('horassem').value,
                        iniciovigencia: document.getElementById('iniciovigencia').value,
                        finalvigencia: document.getElementById('finalvigencia').value,
                        bolsa: document.getElementById('bolsa').value,
                        bolsaextenco: document.getElementById('bolsaextenco').value,
                        nseguro: document.getElementById('nseguro').value,
                        nomeseguradora: document.getElementById('nomeseguradora').value,
                        matricula: document.getElementById('matricula').value,
                        curso: document.getElementById('curso').value,
                        semestre: document.getElementById('semestre').value,
                        enderecodomiciliar: document.getElementById('enderecodomiciliar').value,
                        cep: document.getElementById('cep').value,
                        cidade: document.getElementById('cidade').value,
                        estado: document.getElementById('estado').value,
                        emailestagiario: document.getElementById('emailestagiario').value,
                        departestagio: document.getElementById('departestagio').value,
                        bairroconc: document.getElementById('bairroconc').value,
                        tellconc: document.getElementById('tellconc').value,
                        cepconc: document.getElementById('cepconc').value,
                        cidadeconc: document.getElementById('cidadeconc').value,
                        estadoconc: document.getElementById('estadoconc').value,
                        emailconc: document.getElementById('emailconc').value,
                        siteconc: document.getElementById('siteconc').value,
                        periodoinic: document.getElementById('periodoinic').value,
                        periodofinal: document.getElementById('periodofinal').value,
                        periodoReali: document.getElementById('periodoReali').value,
                        periodoRealt: document.getElementById('periodoRealt').value,
                        hiniciosabado: document.getElementById('hiniciosabado').value,
                        hfinalsabado: document.getElementById('hfinalsabado').value,
                        atividane1: document.getElementById('atividane1').value,
                        descricaoativ1: document.getElementById('descricaoativ1').value,
                        objresult1: document.getElementById('objresult1').value,
                        periodo1: document.getElementById('periodo1').value,
                        atividane2: document.getElementById('atividane2').value,
                        descricaoativ2: document.getElementById('descricaoativ2').value,
                        objresult2: document.getElementById('objresult2').value,
                        periodo2: document.getElementById('periodo2').value,
                        atividane3: document.getElementById('atividane3').value,
                        descricaoativ3: document.getElementById('descricaoativ3').value,
                        objresult3: document.getElementById('objresult3').value,
                        periodo3: document.getElementById('periodo3').value,
                        atividane4: document.getElementById('atividane4').value,
                        descricaoativ4: document.getElementById('descricaoativ4').value,
                        objresult4: document.getElementById('objresult4').value,
                        periodo4: document.getElementById('periodo4').value,
                        atividane5: document.getElementById('atividane5').value,
                        descricaoativ5: document.getElementById('descricaoativ5').value,
                        objresult5: document.getElementById('objresult5').value,
                        periodo5: document.getElementById('periodo5').value
                    };

                    doc.setData(values);

                    try {
                        doc.render();
                    } catch (error) {
                        console.error(error);
                        throw error;
                    }

                    const out = doc.getZip().generate({
                        type: 'blob',
                        mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                    });

                    saveAs(out, 'OBR_Preenchido.docx');
                })
                .catch(error => console.error(error));
        }
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/2.0.5/FileSaver.min.js"></script>
</html>
