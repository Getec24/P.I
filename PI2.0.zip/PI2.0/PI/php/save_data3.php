<?php
require 'config.php';

function encryptData($data) {
    $encryption_key = 'a';
    return openssl_encrypt($data, 'aes-256-cbc', $encryption_key, 0, '1234567890123456');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
     // Recebendo os valores do POST
    $nome = $_POST['nome'];
    $ra = $_POST['ra'];
    $nomedaempresa = $_POST['nomedaempresa'];
    $svrnome = $_POST['svrnome'];
    $cargo = $_POST['cargo'];
    $inicio = $_POST['inicio'];
    $termino = $_POST['termino'];
    $dia = $_POST['dia'];
    $tipo_arquivo = $_POST['tipo_arquivo'];
   
    
    


   
   
    // Preparando a consulta SQL
    $stmt = $pdo->prepare('INSERT INTO relatorio2(
        tipo_arquivo, nome ,ra,nomedaempresa,svrnome,cargo,inicio,termino,dia)
        VALUES (?,?,?,?,?,?,?,?,?)');    

    // Executando a consulta
    $stmt->execute([
        $tipo_arquivo,
        $nome,
        $ra,
        $nomedaempresa,
        $svrnome,
        $cargo,
        $inicio,
        $termino,
        $dia
        
    ]);

    echo "Dados salvos com sucesso!";
}
?>