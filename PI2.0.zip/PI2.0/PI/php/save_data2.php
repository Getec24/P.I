<?php
require 'config.php';

function encryptData($data) {
    $encryption_key = 'a';
    return openssl_encrypt($data, 'aes-256-cbc', $encryption_key, 0, '1234567890123456');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recebendo os valores do POST
    $tipo_arquivo = $_POST['tipo_arquivo'];
    $matricula = $_POST['matricula'];
    $nome = $_POST['nome'];
    $curso = $_POST['curso'];
    $ra = $_POST['ra'];
    $nomedaempresa = $_POST['nomedaempresa'];
    $supervisor = $_POST['supervisor'];
    $cdsde = $_POST['cdsde'];


   
   
    // Preparando a consulta SQL
    $stmt = $pdo->prepare('INSERT INTO relatorio(
        tipo_arquivo,matricula,nome,curso,ra,nomedaempresa,supervisor,cdsde)
        VALUES (?,?,?,?,?,?,?,?)');    

    // Executando a consulta
    $stmt->execute([
        $tipo_arquivo,
        $matricula,
        $nome,
        $curso,
        $ra,
        $nomedaempresa,
        $supervisor,
        $cdsde,
        
    ]);

    echo "Dados salvos com sucesso!";
}
?>