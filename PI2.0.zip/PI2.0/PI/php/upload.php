<?php
// upload.php
require 'config.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $aluno_id = $_SESSION['id'];
    $professor_id = $_POST['professor'];
    $file = $_FILES['file'];

    // Obter a sigla do curso do professor
    $stmt = $pdo->prepare('SELECT c.sigla FROM Curso c JOIN Professor p ON c.id = p.id_curso WHERE p.id = ?');
    $stmt->execute([$professor_id]);
    $curso = $stmt->fetch();

    if ($curso) {
        $curso_sigla = $curso['sigla'];
        $target_dir = "../uploads/$curso_sigla/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        $target_file = $target_dir . basename($file["name"]);
        $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        $max_file_size = 2 * 1024 * 1024; // Limite de 2MB

        // Verificar se o arquivo é um PDF
        if ($file_type != "pdf") {
            echo "Erro: Apenas arquivos PDF são permitidos.";
            exit();
        }

        // Verificar o tamanho do arquivo
        if ($file["size"] > $max_file_size) {
            echo "Erro: O arquivo excede o tamanho máximo permitido de 2MB.";
            exit();
        }

        // Tentar mover o arquivo para o diretório de uploads
        if (move_uploaded_file($file["tmp_name"], $target_file)) {
            // Obter o ID do curso
            $stmt = $pdo->prepare('SELECT id_curso FROM Professor WHERE id = ?');
            $stmt->execute([$professor_id]);
            $id_curso = $stmt->fetchColumn();

            // Inserir registro na tabela Uploads
            $stmt = $pdo->prepare('INSERT INTO Uploads (aluno_id, id_professor, id_curso, file_path) VALUES (?, ?, ?, ?)');
            $stmt->execute([$aluno_id, $professor_id, $id_curso, $target_file]);

            echo "O arquivo " . htmlspecialchars(basename($file["name"])) . " foi enviado com sucesso.";
        } else {
            echo "Desculpe, houve um erro ao enviar seu arquivo.";
        }
    } else {
        echo "Erro: Curso não encontrado.";
    }
}
?>
