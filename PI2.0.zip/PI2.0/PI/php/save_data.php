<?php
require 'config.php';

function encryptData($data) {
    $encryption_key = 'a';
    return openssl_encrypt($data, 'aes-256-cbc', $encryption_key, 0, '1234567890123456');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recebendo os valores do POST
    $tipo_arquivo = $_POST['tipo_arquivo'];
    $concedente = $_POST['concedente'];
    $cnpj = $_POST['cnpj'];
    $ruaconcedente = $_POST['ruaconcedente'];
    $nomerepresentante = $_POST['nomerepresentante'];
    $cargorepresentante = $_POST['cargorepresentante'];
    $cpf = encryptData($_POST['cpf']);
    $nomeestagiario = $_POST['nomeestagiario'];
    $rgestudante = encryptData($_POST['rgestudante']);
    $ruaestagiario = $_POST['ruaestagiario'];
    $cidadeestagio = $_POST['cidadeestagio'];
    $hinicio = $_POST['hinicio'];
    $hfinal = $_POST['hfinal'];
    $refinicio = $_POST['refinicio'];
    $refifinal = $_POST['refifinal'];
    $horassem = $_POST['horassem'];
    $iniciovigencia = $_POST['iniciovigencia'];
    $finalvigencia = $_POST['finalvigencia'];
    $bolsa = $_POST['bolsa'];
    $bolsaextenco = $_POST['bolsaextenco'];
    $nseguro = $_POST['nseguro'];
    $nomeseguradora = $_POST['nomeseguradora'];
    $matricula = $_POST['matricula'];
    $curso = $_POST['curso'];
    $semestre = $_POST['semestre'];
    $enderecodomiciliar = $_POST['enderecodomiciliar'];
    $cep = $_POST['cep'];
    $cidade = $_POST['cidade'];
    $estado = $_POST['estado'];
    $emailestagiario = $_POST['emailestagiario'];
    $departestagio = $_POST['departestagio'];
    $bairroconc = $_POST['bairroconc'];
    $tellconc = $_POST['tellconc'];
    $cepconc = $_POST['cepconc'];
    $cidadeconc = $_POST['cidadeconc'];
    $estadoconc = $_POST['estadoconc'];
    $emailconc = $_POST['emailconc'];
    $siteconc = $_POST['siteconc'];
    $periodoinic = $_POST['periodoinic'];
    $periodofinal = $_POST['periodofinal'];
    $periodoReali = $_POST['periodoReali'];
    $periodoRealt = $_POST['periodoRealt'];
    $hiniciosabado = $_POST['hiniciosabado'];
    $hfinalsabado = $_POST['hfinalsabado'];
    $atividane1 = $_POST['atividane1'];
    $descricaoativ1 = $_POST['descricaoativ1'];
    $objresult1 = $_POST['objresult1'];
    $periodo1 = $_POST['periodo1'];
    $atividane2 = $_POST['atividane2'];
    $descricaoativ2 = $_POST['descricaoativ2'];
    $objresult2 = $_POST['objresult2'];
    $periodo2 = $_POST['periodo2'];
    $atividane3 = $_POST['atividane3'];
    $descricaoativ3 = $_POST['descricaoativ3'];
    $objresult3 = $_POST['objresult3'];
    $periodo3 = $_POST['periodo3'];
    $atividane4 = $_POST['atividane4'];
    $descricaoativ4 = $_POST['descricaoativ4'];
    $objresult4 = $_POST['objresult4'];
    $periodo4 = $_POST['periodo4'];
    $atividane5 = $_POST['atividane5'];
    $descricaoativ5 = $_POST['descricaoativ5'];
    $objresult5 = $_POST['objresult5'];
    $periodo5 = $_POST['periodo5'];

    // Preparando a consulta SQL
    $stmt = $pdo->prepare('INSERT INTO estagios (
        tipo_arquivo, concedente, cnpj, ruaconcedente, nomerepresentante, cargorepresentante, cpf, 
        nomeestagiario, rgestudante, ruaestagiario, cidadeestagio, hinicio, hfinal, refinicio, refifinal, horassem, iniciovigencia, finalvigencia, 
        bolsa, bolsaextenco, nseguro, nomeseguradora, matricula, curso, semestre, 
        enderecodomiciliar, cep, cidade, estado, emailestagiario, departestagio, bairroconc, tellconc, cepconc, cidadeconc, estadoconc, emailconc, siteconc, 
        periodoinic, periodofinal, periodoReali, periodoRealt, hiniciosabado, hfinalsabado, 
        atividane1, descricaoativ1, objresult1, periodo1, 
        atividane2, descricaoativ2, objresult2, periodo2, 
        atividane3, descricaoativ3, objresult3, periodo3, 
        atividane4, descricaoativ4, objresult4, periodo4, 
        atividane5, descricaoativ5, objresult5, periodo5
    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');    

    // Executando a consulta
    $stmt->execute([
        $tipo_arquivo,
        $concedente,
        $cnpj,
        $ruaconcedente,
        $nomerepresentante,
        $cargorepresentante,
        $cpf,
        $nomeestagiario,
        $rgestudante,
        $ruaestagiario,
        $cidadeestagio,
        $hinicio,
        $hfinal,
        $refinicio,
        $refifinal,
        $horassem,
        $iniciovigencia,
        $finalvigencia,
        $bolsa,
        $bolsaextenco,
        $nseguro,
        $nomeseguradora,
        $matricula,
        $curso,
        $semestre,
        $enderecodomiciliar,
        $cep,
        $cidade,
        $estado,
        $emailestagiario,
        $departestagio,
        $bairroconc,
        $tellconc,
        $cepconc,
        $cidadeconc,
        $estadoconc,
        $emailconc,
        $siteconc,
        $periodoinic,
        $periodofinal,
        $periodoReali,
        $periodoRealt,
        $hiniciosabado,
        $hfinalsabado,

        $atividane1,
        $descricaoativ1,
        $objresult1,
        $periodo1,

        $atividane2,
        $descricaoativ2,
        $objresult2,
        $periodo2,

        $atividane3,
        $descricaoativ3,
        $objresult3,
        $periodo3,

        $atividane4,
        $descricaoativ4,
        $objresult4,
        $periodo4,

        $atividane5,
        $descricaoativ5,
        $objresult5,
        $periodo5
    ]);

    echo "Dados salvos com sucesso!";
}
?>