<?php include 'header.php'; ?>
<main>
    <div class="content">
        <div class="contacts">
            <h2>Contatos da Fatec</h2>
            <ul>
                <li>Email: fatec@example.com</li>
                <li>Telefone: (19) 1234-5678</li>
                <li>Endereço: Rua Exemplo, 123, Itapira - SP</li>
            </ul>
            <h2>Contatos de Coordenadores de curso </h2>
            <ul>
                <li>Nome: JOSÉ GONÇALVES PINTO JUNIOR</li>
                <li>Email: fatec@example.com</li>
                <li>Telefone: (19) 1234-5678</li>
                <li>Curso: Desenvolvimento de Software Multiplataforma</li>
            </ul>
            <ul>
                <li>Nome: LUCIENE RELA ARAKAKI FUINI</li>
                <li>Email: fatec@example.com</li>
                <li>Telefone: (19) 1234-5678</li>
                <li>Curso: Gestão da Produção Industrial</li>
            </ul>
            <ul>
                <li>Nome: HERMAS AMARAL GERMEK</li>
                <li>Email: fatec@example.com</li>
                <li>Telefone: (19) 1234-5678</li>
                <li>Curso: Gestão da Tecnologia da Informação</li>
            </ul>
            <ul>
                <li>Nome: WLADIMIR JOSÉ CAMILLO MENEGASSI</li>
                <li>Email: fatec@example.com</li>
                <li>Telefone: (19) 1234-5678</li>
                <li>Curso: Gestão Empresarial</li>
            </ul>
        </div>
        <div class="news-carousel">
            <h2>Notícias</h2>
            <div class="carousel">
                <!-- Conteúdo do carrossel de notícias -->
                <p>Notícia 1</p>
                <p>Notícia 2</p>
                <p>Notícia 3</p>
            </div>
        </div>
    </div>
</main>
</html>
