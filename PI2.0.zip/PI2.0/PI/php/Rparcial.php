<?php
// EstagioObrR.php
include 'header.php';
?>
<link rel="stylesheet" href="../css/estagio.css">
<script src="../js/pizzip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.7.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/docxtemplater/3.22.3/docxtemplater.js"></script>
<main>
    <div class="content">
        <div class="form-section">
            <h2>Rparcial</h2>
            <form id="rparcial">
                <!-- Form Fields -->
                <div class="input-group">
                    <label for="matricula">Matrícula: </label>
                    <input type="text" id="matricula" name="matricula" required>
                </div>
                <div class="input-group">
                    <label for="nome">Nome:</label>
                    <input type="text" id="nome" name="nome" required>
                </div>
                <div class="input-group">
                    <label for="curso">Curso:</label>
                    <input type="text" id="curso" name="curso" required>
                </div>
                <div class="input-group">
                    <label for="semestre">Semestre:</label>
                    <input type="text" id="semestre" name="semestre" required>
                </div>
                <div class="input-group">
                    <label for="ra">RA: </label>
                    <input type="text" id="ra" name="ra" required>
                </div>
                <div class="input-group">
                    <label for="nomedaempresa">Nome da Empresa:</label>
                    <input type="text" id="nomedaempresa" name="nomedaempresa" required>
                </div>
                <div class="input-group">
                    <label for="supervisor">Nome do supervisor do estagiário:</label>
                    <input type="text" id="supervisor" name="supervisor" required>
                </div>
                <div class="input-group">
                    <label for="cdsde">Cargo do supervisor do estagiário: </label>
                    <input type="text" id="cdsde" name="cdsde" required>
                </div>
                <input type="hidden" id="tipo_arquivo" name="tipo_arquivo" value="Relatorio Parcial">
                <button type="submit">Enviar</button>
            </form>
    <script>
        document.getElementById('rparcial').addEventListener('submit', function(event) {
            event.preventDefault();
            
            const formData = new FormData(document.getElementById('rparcial'));

            fetch('save_data2.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                alert('Dados salvos com sucesso!');
                console.log(data);
            })
            .catch(error => {
                alert('Erro ao salvar os dados.');
                console.error(error);
            });

            generateDocx();
        });

        function generateDocx() {
            fetch('../DocBase/rp.docx')
                .then(response => response.arrayBuffer())
                .then(data => {
                    const zip = new PizZip(data);
                    const doc = new window.docxtemplater(zip, { paragraphLoop: true, linebreaks: true });

                    const values = {    
                        matricula: document.getElementById('matricula').value,
                        nome: document.getElementById('nome').value,
                        curso: document.getElementById('curso').value,
                        semestre: document.getElementById('semestre').value,
                        ra: document.getElementById('ra').value,
                        nomedaempresa: document.getElementById('nomedaempresa').value,
                        supervisor: document.getElementById('supervisor').value,
                        cdsde: document.getElementById('cdsde').value,
                        
                    };

                    doc.setData(values);

                    try {
                        doc.render();
                    } catch (error) {
                        console.error(error);
                        throw error;
                    }

                    const out = doc.getZip().generate({
                        type: 'blob',
                        mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                    });

                    saveAs(out, 'Relatorio_Parcial.docx');
                })
                .catch(error => console.error(error));
        }
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/2.0.5/FileSaver.min.js"></script>
</html>
