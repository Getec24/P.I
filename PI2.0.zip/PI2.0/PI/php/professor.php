<?php
// professor.php
include 'header_professor.php';
require 'config.php';

// Obter o ID do professor da sessão
$professor_id = $_SESSION['id'];

// Obter os alunos com uploads vinculados ao professor
$stmt = $pdo->prepare('SELECT DISTINCT a.id, a.nome FROM Aluno a JOIN Uploads u ON a.id = u.aluno_id WHERE u.id_professor = ?');
$stmt->execute([$professor_id]);
$alunos = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<link rel="stylesheet" href="../css/professor.css">
<main>
    <div class="content">
        <h2>Alunos Vinculados</h2>
        <ul>
            <?php foreach ($alunos as $aluno): ?>
                <li>
                    <a href="#" class="aluno-link" data-aluno-id="<?php echo $aluno['id']; ?>"><?php echo htmlspecialchars($aluno['nome']); ?></a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>

    <div id="modal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Documentos de <span id="aluno-nome"></span></h2>
            <table id="uploads-table">
                <thead>
                    <tr>
                        <th>Tipo do Arquivo</th>
                        <th>Nome do Arquivo</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Conteúdo preenchido via JavaScript -->
                </tbody>
            </table>
            <h3>Chat com <span id="aluno-nome-chat"></span></h3>
            <div class="chat-box" id="chat-box">
                <!-- Conteúdo preenchido via JavaScript -->
            </div>
            <form id="chat-form">
                <textarea name="chat_message" id="chat_message"></textarea>
                <button type="submit">Enviar</button>
            </form>
        </div>
    </div>
</main>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const modal = document.getElementById('modal');
        const closeModal = document.getElementsByClassName('close')[0];

        document.querySelectorAll('.aluno-link').forEach(link => {
            link.addEventListener('click', function(event) {
                event.preventDefault();
                const alunoId = this.getAttribute('data-aluno-id');
                const alunoNome = this.textContent;

                document.getElementById('aluno-nome').textContent = alunoNome;
                document.getElementById('aluno-nome-chat').textContent = alunoNome;

                fetch('get_uploads.php?aluno_id=' + alunoId)
                    .then(response => response.json())
                    .then(data => {
                        if (data.error) {
                            alert('Erro: ' + data.error);
                            return;
                        }

                        const tableBody = document.querySelector('#uploads-table tbody');
                        tableBody.innerHTML = '';

                        data.uploads.forEach(upload => {
                            const fileName = upload.file_path.split('/').pop();
                            const row = document.createElement('tr');
                            row.innerHTML = `
                                <td>${upload.file_type}</td>
                                <td><a href="${upload.file_path}" download>${fileName}</a></td>
                                <td>
                                    <select class="status-select" data-upload-id="${upload.id}">
                                        <option value="0" ${upload.status == 0 ? 'selected' : ''}>Reprovado</option>
                                        <option value="1" ${upload.status == 1 ? 'selected' : ''}>Aprovado</option>
                                    </select>
                                </td>
                            `;
                            tableBody.appendChild(row);
                        });

                        document.querySelectorAll('.status-select').forEach(select => {
                            select.addEventListener('change', function() {
                                const uploadId = this.getAttribute('data-upload-id');
                                const status = this.value;

                                fetch('update_status.php', {
                                    method: 'POST',
                                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                                    body: `upload_id=${uploadId}&status=${status}`
                                });
                            });
                        });

                        const chatBox = document.getElementById('chat-box');
                        chatBox.innerHTML = '';

                        data.chats.forEach(chat => {
                            const chatMessage = document.createElement('div');
                            chatMessage.classList.add('chat-message', chat.sender.toLowerCase());
                            chatMessage.innerHTML = `
                                <p>${chat.message}</p><br>
                                <span class="timestamp">${chat.timestamp}</span>
                            `;
                            chatBox.appendChild(chatMessage);
                        });

                        modal.style.display = 'block';
                    })
                    .catch(error => {
                        alert('Erro ao buscar dados: ' + error.message);
                    });
            });
        });

        closeModal.onclick = function() {
            modal.style.display = 'none';
        };

        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = 'none';
            }
        };

        document.getElementById('chat-form').addEventListener('submit', function(event) {
            event.preventDefault();

            const alunoNome = document.getElementById('aluno-nome-chat').textContent;
            const chatMessage = document.getElementById('chat_message').value;

            if (chatMessage.trim() === '') {
                alert('A mensagem não pode estar vazia.');
                return;
            }

            fetch('send_chat.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `aluno_nome=${alunoNome}&chat_message=${chatMessage}`
            }).then(() => {
                const chatBox = document.getElementById('chat-box');
                const chatMessageDiv = document.createElement('div');
                chatMessageDiv.classList.add('chat-message', 'professor');
                chatMessageDiv.innerHTML = `
                    <p>${chatMessage}</p><br>
                    <span class="timestamp">Agora</span>
                `;
                chatBox.appendChild(chatMessageDiv);
                document.getElementById('chat_message').value = '';
                alert('Mensagem enviada com sucesso.');
                modal.style.display = 'none';
            });
        });
    });
</script>
</html>
