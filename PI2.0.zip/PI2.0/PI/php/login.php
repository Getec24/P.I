<?php
// login.php
session_start();
require 'config.php';

$ra = $_POST['ra'];
$password = $_POST['password'];
$user_type = $_POST['user_type'];

if ($user_type === 'aluno') {
    $stmt = $pdo->prepare('SELECT * FROM Aluno WHERE ra = ?');
    $stmt->execute([$ra]);
    $user = $stmt->fetch();

    if ($user) {
        if ($password == $user['senha']) {
            $_SESSION['id'] = $user['id'];
            $_SESSION['nome'] = $user['nome'];
            $_SESSION['user_type'] = 'aluno';
            header('Location: home.php');
            exit();
        } else {
            header('Location: ../index.html?error=Senha inválida para Aluno.');
            exit();
        }
    } else {
        header('Location: ../index.html?error=Aluno não encontrado.');
        exit();
    }
} elseif ($user_type === 'professor') {
    $stmt = $pdo->prepare('SELECT * FROM Professor WHERE rm = ?');
    $stmt->execute([$ra]);
    $user = $stmt->fetch();

    if ($user) {
        if ($password == $user['senha']) {
            $_SESSION['id'] = $user['id'];
            $_SESSION['nome'] = $user['nome'];
            $_SESSION['user_type'] = 'professor';
            header('Location: professor.php');
            exit();
        } else {
            header('Location: ../index.html?error=Senha inválida para Professor.');
            exit();
        }
    } else {
        header('Location: ../index.html?error=Professor não encontrado.');
        exit();
    }
}
?>
