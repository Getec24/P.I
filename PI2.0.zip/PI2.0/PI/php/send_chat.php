<?php
require 'config.php';

$aluno_nome = $_POST['aluno_nome'];
$chat_message = $_POST['chat_message'];

// Obter ID do aluno com base no nome
$stmt = $pdo->prepare('SELECT id FROM Aluno WHERE nome = ?');
$stmt->execute([$aluno_nome]);
$aluno_id = $stmt->fetchColumn();

$stmt = $pdo->prepare('INSERT INTO Chat (aluno_id, message, sender) VALUES (?, ?, "Professor")');
$stmt->execute([$aluno_id, $chat_message]);
?>
