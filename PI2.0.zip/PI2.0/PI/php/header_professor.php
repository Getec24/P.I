<?php
session_start();
require 'config.php';

$professor_id = $_SESSION['id'];

// Obter informações do professor
$stmt = $pdo->prepare('SELECT p.nome, c.nome AS curso FROM Professor p JOIN Curso c ON p.id_curso = c.id WHERE p.id = ?');
$stmt->execute([$professor_id]);
$professor = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portal de Estágio</title>
    <link rel="stylesheet" href="../css/home.css">
    <link rel="stylesheet" href="../css/documentacao.css">
</head>
<body>
    <header>
        <div class="header-content">
            <div class="welcome">
            Bem-vindo, <?php echo htmlspecialchars($professor['nome']); ?> - <?php echo htmlspecialchars($professor['curso']); ?>
            </div>
            <nav>
                <ul>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>
</body>
</html>

