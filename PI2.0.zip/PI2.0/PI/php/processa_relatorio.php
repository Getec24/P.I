<?php
// processa_relatorio.php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tipo_relatorio = $_POST['tipo_relatorio'];
    
    if ($tipo_relatorio == 'Parcial') {
        header('Location: Rparcial.php');
    } else {
        header('Location: RFinal.php');
    }
    exit();
}
?>
